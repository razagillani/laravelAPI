<!DOCTYPE html>
<html>
<head>
    <title>Rest API Testing</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    <style>nav.flex.items-center.justify-between div:nth-child(2)>div:nth-child(2) {
    display: none;
}</style>
</head>
<body>
  
<div class="container" style="padding-top:100px;">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\example-app\resources\views/products/layout.blade.php ENDPATH**/ ?>